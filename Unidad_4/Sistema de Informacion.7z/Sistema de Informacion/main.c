//----------------------------Balderrabano Rodriguez Ricardo-----------------
//----------------------------Guerrero Cangas Kevin Ricardo------------------
//----------------------------Matamoros Balderas Arturo----------------------
//----------------------------Oliva Hernandez Ian Yared----------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int vueltas;

void t_vueltas(float total[][vueltas],float tiempo_v[vueltas],int corredor){
	int i,v;
	for(i=0;i<vueltas;i++){
		if(i==0)
		tiempo_v[i]=total[corredor-1][i];
		else
		tiempo_v[i]=total[corredor-1][i]-total[corredor-1][i-1];
	}
}

int main(int argc, char *argv[])
{
  int n_corredores,i,v,seguro=0,num_corredor,cuentas[9]={0},corredor;
  float tiempofi;
  
  printf("Sistema de informacion\n\n");
  printf("Introduzca el numero de corredores(maximo 10): ");
  scanf("%d%*c",&n_corredores);
  printf("Introduzca el numero de vueltas de la carrera: ");
  scanf("%d%*c",&vueltas);
  printf("\n");
  
  char nombre_c[n_corredores][100],nombre[100]={0};
  
  for(i=0;i<n_corredores;i++){
        printf("Introduzca el nombre del corredor %d: ",i+1);
        gets(nombre_c[i]);
   }
  
  printf("\n");         
  
  float tiempo[n_corredores][vueltas];
  char start,finish;
  system("cls");
printf("Para iniciar la carrera introduzca >s< ");
	
	scanf("%s",&start);
	if(start=='s'){
		printf("CORREDORES!!!!\n");
		sleep(1);
		printf("LISTOS!!!\n");
		sleep(1);
		printf("FUERA!!!!!!!!!\n");
		
		clock_t start = clock();//Empieza el conteo de mi tiempo
		while(seguro<n_corredores*vueltas){
			scanf("%d",&num_corredor);			  
			switch(num_corredor){
				case 1:
				  if(cuentas[0]<vueltas){
					    tiempo[0][cuentas[0]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[0]+=1;
						seguro+=1;	
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
				case 2:
				  if(num_corredor>n_corredores){
				  printf("No hay corredor %d en la carrera\n",num_corredor);break;}				  	
				  if(cuentas[1]<vueltas){
					    tiempo[1][cuentas[1]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[1]+=1;
						seguro+=1;	
					
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
				case 3:
				  if(num_corredor>n_corredores){
				  printf("No hay corredor %d en la carrera\n",num_corredor);break;}		
				  if(cuentas[2]<vueltas){
					    tiempo[2][cuentas[2]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[2]+=1;
						seguro+=1;	
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
				case 4:
				  if(num_corredor>n_corredores){
				  printf("No hay corredor %d en la carrera\n",num_corredor);break;}		
				  if(cuentas[3]<vueltas){
					    tiempo[3][cuentas[3]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[3]+=1;
						seguro+=1;	
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
				case 5:
				  if(num_corredor>n_corredores){
				  printf("No hay corredor %d en la carrera\n",num_corredor);break;}		
				  if(cuentas[4]<vueltas){
					    tiempo[4][cuentas[4]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[4]+=1;
						seguro+=1;	
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
				case 6:
				  if(num_corredor>n_corredores){
				  printf("No hay corredor %d en la carrera\n",num_corredor);break;}		
				  if(cuentas[5]<vueltas){
					    tiempo[5][cuentas[5]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[5]+=1;
						seguro+=1;	
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
				case 7:
				  if(num_corredor>n_corredores){
				  printf("No hay corredor %d en la carrera\n",num_corredor);break;}		
				  if(cuentas[6]<vueltas){
					    tiempo[6][cuentas[6]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[6]+=1;
						seguro+=1;	
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
				case 8:
				  if(num_corredor>n_corredores){
				  printf("No hay corredor %d en la carrera\n",num_corredor);break;}		
				  if(cuentas[7]<vueltas){
					    tiempo[7][cuentas[7]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[7]+=1;
						seguro+=1;	
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
				case 9:
				  if(num_corredor>n_corredores){
				  printf("No hay corredor %d en la carrera\n",num_corredor);break;}	
				  if(cuentas[8]<vueltas){
					    tiempo[8][cuentas[8]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[8]+=1;
						seguro+=1;	
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
				case 10:
				  if(num_corredor>n_corredores){
				  printf("No hay corredor %d en la carrera\n",num_corredor);break;}		
				  if(cuentas[9]<vueltas){
					    tiempo[9][cuentas[9]]=((double)clock()-start)/CLOCKS_PER_SEC;
						cuentas[9]+=1;
						seguro+=1;	
				   }
				  else printf("El corredor %d ya termino la carrera\n",num_corredor); break;
			}
		}
	}

  float almacena;
  
  float corredores_num[n_corredores][vueltas];
  for(i=0;i<n_corredores;i++){
      for(v=0;v<vueltas+1;v++){
      	corredores_num[i][v]=tiempo[i][v];
	  }
	}
	
  char nombres[n_corredores][100];
   for(i=0;i<n_corredores;i++){
      	strcpy(nombres[i],nombre_c[i]);
	}

   
  for(v=1;v<n_corredores;v++){
      for(i=0;i<n_corredores-1;i++){ //realiza el acomodamiento de los valores
        		if(tiempo[i][vueltas-1]>tiempo[i+1][vueltas-1]){
        			almacena=tiempo[i][vueltas-1];
        			tiempo[i][vueltas-1]=tiempo[i+1][vueltas-1];
        			tiempo[i+1][vueltas-1]=almacena;
        			strcpy(nombre,nombre_c[i]);
        			strcpy(nombre_c[i],nombre_c[i+1]);
        			strcpy(nombre_c[i+1],nombre);
        			
    		}
    	}
    }
  
          
  printf("\nTiempo y posicion de cada corredor\n");
  for(i=0;i<n_corredores;i++){
          printf("Lugar %d: %s  Tiempo:%.2f\n",i+1,nombre_c[i],tiempo[i][vueltas-1]);
         
    } 
  
  float tiempo_v[vueltas];  
  char pregunta;
  fflush(stdin);
  printf("\nDesea conocer el tiempo por vuelta de algun corredor? s/n\n");
  scanf("%c",&pregunta);
  
  while(pregunta=='s'){
  	  printf("\nIntroduzca el numero del corredor del que desea\nconocer su tiempo por vuelta: ");
	  scanf("%d",&corredor);
	  fflush (stdin);
	  t_vueltas(corredores_num,tiempo_v,corredor);
	  printf("\nCorredor %d: %s\n",corredor,nombres[corredor-1]);
	  for(i=0;i<vueltas;i++)
	     printf("Vuelta %d: %f\n",i+1,tiempo_v[i]);
	  printf("\nDesea conocer el tiempo de otro corredor? s/n\n");
	  scanf("%c",&pregunta);
    }
  
  system("PAUSE");	
  return 0;
}
