/*
ARTURO MATAMOROS BALDERAS
1VM1 PP19093671
El programa realizara el promedio de un alumno con 5
calificaciones que proporcionara el usuario, colocando la 
palabra "aprovado" en caso de que su promedio sea >=6
en caso de ser menor colocar la palabra "no aprobado"
*/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  
  float suma,prome,x,calif[5];
  int cant;
  
  suma=0;
  
  for(cant=1;cant<=5;cant++){
      printf("Coloque el valor de la calificacion_%d de 0 a 10: \t",cant);
      scanf("%f",&calif[cant]);
      suma = suma + calif[cant];
  }
  
  prome=suma/5;
  printf("Su promedio es: \t %.2f\n",prome);
  printf("Usted esta:\t");
  if(prome>=6){
  	printf("Aprobado\n");
  }
  else{
  	printf("No Aprobado\n");
  }
  system("PAUSE");	
  return 0;
}
