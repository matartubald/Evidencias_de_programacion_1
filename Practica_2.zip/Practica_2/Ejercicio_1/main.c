/*
ARTURO MATAMOROS BALDERAS
1IMV1 PP19093671
 El programa resolvera una funcion dada la variables x
 por el usuario
 siendo para x <= 0  x^2-x
 siendo para x >  0 -x^2+3x
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int x,fx;
  
  
  printf("Para resolver la funcion dada:\n");
  printf("para x <= 0  x^2-x\npara x >  0 -x^2+3x\n");
  printf("Proporcione el valor de X:");       //Entrada de valores
  scanf("%d",&x);
  
  if(x<=0){      //Sentencia de control
     fx=(x^2)-x;
  } 
  else{
     fx=3*x-(x*x);
  }
  
  printf("El resultado de la funcion:\t%d\n",fx);        //Salida de valores
  
  system("PAUSE");	
  return 0;
}
