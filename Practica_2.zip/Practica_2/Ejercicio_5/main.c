/*
ARTURO MATAMOROS BALDERAS  1MV1
 Escribir un programa que simule a una calculadora simple. 
 Lee dos enteros y un car�cter. Si el car�cter es un +, se 
 imprime la suma, si es un -, se imprime la diferencia, si 
 es un *, se imprime el producto, si es un /, se imprime 
 el cociente. La calculadora se repite hasta que el usuario 
 escriba �S� o �s�para salir. 
*/
#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float num1, num2, total;
	char operador,letra;
	int cant;
		
	printf("PARA LA SIMULACION DE LA CALCULADORA:\n");
	printf("Si desea Salir del programa al final coloque (S) o (s)\n\n");
	do{
             
		total =0;
	printf("\nOperacion\n");
    printf("Introduce la primer sifra:\t");
		scanf("%f%*c",&num1);
    printf("Introduce el operador deseado (+, -, *, /):\t");
		scanf("%c",&operador);
	printf("Introduce la segunda sifra:\t");
		scanf("%f%*c",&num2);
	
	switch(operador){
		case '+':
		total=num1+num2;
		break;
		
		case '-':
		total=num1-num2;
		break;
		
		case '*':
		total=num1*num2;
		break;
		
		case '/':
		total=num1/num2;
		break;
	    }		
	printf("El resultado de la operacion es:\t%.2f\n\n",total);
	printf("Desea salir de la calculadora si(S) no (N):\t");
        scanf("%s",&letra);
    
	}while(letra==('n'|'N'));
	
	
	return 0;
}
