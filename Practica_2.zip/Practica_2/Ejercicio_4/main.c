#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int num_productos,total,seleccion,num;
	char venta;
	total=0;
	
	printf("MENU\n");
	printf("1. Hambuerguesa chica con papas y refresco  $20\n");
	printf("2. Hotdog y refresco                        $18\n");
	printf("3. Ensalada rusa                            $15\n");
	printf("Seleccione cuantos productos desea comprar:\t\t");
	    scanf("%d",&num_productos);
    for(num=1;num<=num_productos;num++){
        printf("Producto_%d\nColoque el numero del producto deseado:\t",num);
        scanf("%d",&seleccion);                               
		switch(seleccion){
			case 1:
				total=total+20;
				break;
			case 2:
				total=total+18;
				break;
			case 3:
				total=total+15;
				break;
		}
    }	
	printf("El valor de su compra es:\t$ %d\n",total);
	system("PAUSE");
	return 0;
}
