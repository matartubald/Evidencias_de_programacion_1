/*
ARTURO MATAMOROS BALDERAS   1MV1
Problema de aplicacion: Realizar el control de un invernadero con 
4 tipos diferentes de cosechas
*/
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char cosecha;
	float temp;
	
	printf("INVERNADERO:\n");
	printf("Las cosechas incluidas:\n");
	printf(" (T) Tomate \n (M) Melon \n (P) Pepino\n (C) Calabacita\n");
	printf("Seleccione la cosecha que desea obsevar:  ");
		scanf("%c",&cosecha);
	switch(cosecha){
		
		case 'T'|'t':
		printf("La temperatura del cultivo expresada en porciento:  ");
			scanf("%f",&temp);
		while(temp>60){
			printf("Ventanillas abiertas.\n");
			Sleep(5000);
			printf("Ventanillas cerradas.\n");
			temp=temp-3;
			printf("\tLa humedad es:  %.2f\n",temp);
		}
		while(temp<50){
			printf("Sistema de riego encencidido.\n");
			Sleep(3000);
			printf("Sistema de riego apagado.\n");
			temp=temp+4;
			printf("\tLa humedad es:  %.2f\n",temp);
		}
		printf("\nPORCIENTO DE LA HUMEDAD RELATIVA OPTIMO.\n");
		break;
		
		case 'M'|'m':
		printf("La temperatura del cultivo expresada en porciento:  ");
			scanf("%f",&temp);
		while(temp>70){
			printf("Ventanillas abiertas.\n");
			Sleep(5000);
			printf("Ventanillas cerradas.\n");
			temp=temp-3;
			printf("\tLa humedad es:  %.2f\n",temp);
		}
		while(temp<60){
			printf("Sistema de riego encencidido.\n");
			Sleep(3000);
			printf("Sistema de riego apagado.\n");
			temp=temp+4;
			printf("\tLa humedad es:  %.2f\n",temp);
		}
		printf("\nPORCIENTO DE LA HUMEDAD RELATIVA OPTIMO.\n");
		break;
		
		case 'P'|'p':
		printf("La temperatura del cultivo expresada en porciento:  ");
			scanf("%f",&temp);
		while(temp>90){
			printf("Ventanillas abiertas.\n");
			Sleep(5000);
			printf("Ventanillas cerradas.\n");
			temp=temp-3;
			printf("\tLa humedad es:  %.2f\n",temp);
		}
		while(temp<70){
			printf("Sistema de riego encencidido.\n");
			Sleep(3000);
			printf("Sistema de riego apagado.\n");
			temp=temp+4;
			printf("\tLa humedad es:  %.2f\n",temp);
		}
		printf("\nPORCIENTO DE LA HUMEDAD RELATIVA OPTIMO.\n");
		break;
		
		case 'C'|'c':
		printf("La temperatura del cultivo expresada en porciento:  ");
			scanf("%f",&temp);
		while(temp>80){
			printf("Ventanillas abiertas.\n");
			Sleep(5000);
			printf("Ventanillas cerradas.\n");
			temp=temp-3;
			printf("\tLa humedad es:  %.2f\n",temp);
		}
		while(temp<55){
			printf("Sistema de riego encencidido.\n");
			Sleep(3000);
			printf("Sistema de riego apagado.\n");
			temp=temp+4;
			printf("\tLa humedad es:  %.2f\n",temp);
		}
		printf("\nPORCIENTO DE LA HUMEDAD RELATIVA OPTIMO.\n");
		break;
	}
	return 0;
}
