/*
ARTURO MATAMOROS BALDERAS  19093671
1MV1
Dise�ar un programa el cual calcule el cobro de luz 
atraves de los KWH utilizados, que sera un dato que
proporcionara el usuario
*/
#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float a,b,costo,cuota;
	int kwh;
	
	costo=0;
	cuota=52.84;
	
	printf("Para calcular el cobro de la luz.\nIngrese el valor de KWH utilizados:\t");
	scanf("%d",&kwh);
	
	printf("\nSi se consume : %d KWH entonces:\n",kwh);
	printf("Cuota fija:            $   %4.2f\n",cuota);
	
	if(kwh<=50){
		costo=(kwh*2.288)+cuota;
		printf("Total:                 $  %4.2f\n",costo);
	}
	else if(kwh<=100){
		costo=50*2.288;
		printf("Los primeros 50:       $  %.2f\t",costo);
		costo=kwh-50;
		printf("quedan: %.0f\n",costo);
		costo=costo*2.762;
		printf("Del 51 al 100:         $  %.2f\n",costo);
		costo=((50*2.288)+((kwh-50)*2.762))+cuota;
		printf("Total:                 $  %4.2f\n",costo);
	}
	else{
		costo=50*2.288;
		printf("Los primeros 50:       $  %.2f\t",costo);
		costo=kwh-50;
		printf("quedan: %.0f\n",costo);
		costo=50*2.762;
		printf("Del 51 al 100:         $  %.2f\t",costo);
		costo=kwh-100;
		printf("quedan: %.0f\n",costo);
		printf("Los %.0f adicionales:    $  ",costo);
		costo=costo*3.042;
		printf("%.2f\n",costo);
		costo=(50*2.288)+(50*2.762)+costo+cuota;
		printf("Total:                 $  %4.2f\n",costo);
	}
	system("PAUSE");
	return 0;
}
