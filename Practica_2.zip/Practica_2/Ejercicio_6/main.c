/*
ARTURO MATAMOROS BALDERAS  1MV1
Escribir un programa que presente los valores de la 
funci�n seno(2x)-x para 0, 0.5, 1.0,�, 9.5, 10.
*/
#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float x, fx;
	int mas;
	
	printf("Este programa presenta la presentacion de la grafica de la funcion seno(2x)-x\n");
	printf("Los valores que se utilizaran para x son: desde 0.5-10\n\n");
	
	for(x=0.5;x<=10;x+=0.5){
		printf("Para fx(%.1f)=seno(2(%.1f))-(%.1f):\n",x,x,x);
		fx=sin(2*x)-x;
		printf("\t%.2f\n",fx);
	}
	system("PAUSE");
	return 0;
}
